#!/bin/sh

echo $RANDOM > number.txt