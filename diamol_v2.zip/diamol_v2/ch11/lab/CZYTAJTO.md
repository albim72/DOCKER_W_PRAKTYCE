# Rozdział 11. - Laboratorium - Przykładowe rozwiązanie

## Plik przesłaniający

Utwórz plik `docker-compose-build.yml` o następującej zawartości:

```
version: "3.7"

services:
  todo-web:
    build:
      context: todo-list
      dockerfile: Dockerfile
      args:
        BUILD_NUMBER: ${BUILD_NUMBER:-0}
```

## Zadanie Jenkinsa

- Zaloguj się do Jenkinsa.

- Utwórz nowe zadanie, stanowiące kopię zadania `diamol`.

- Zmień ścieżkę skryptu na ch11/lab/Jenkinsfile

- Kliknij przycisk Build Now

- Sprawdź czy obraz został przekazany do rejestru Dockera:

```
curl http://registry.local:5000/v2/diamol/ch11-todo-list/tags/list
```
